mapper
======

mapper is a small web app that will give you the git revision for a given hg revision and hg-git mapfile

## Prerequisites

    * bottle (http://bottlepy.org/)

